const jwt = require("jsonwebtoken");

module.exports = function (req, res, next) {
  try {
    const token = req.header("Authorization");

    if (!token) {
      return res.status(401).json({ message: "No token, access denied" });
    }

    const verified = jwt.verify(token, "secretkey");
    req.user = verified;

    next();
  } catch (error) {
    res.status(401).json({ message: "Invalid token" });
  }
};